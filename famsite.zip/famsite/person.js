db[1]=new Person("1,Test-GrandPa,,M,0,0,2,,,,");
db[2]=new Person("2,Test_GrandMom,,F,0,0,1,,,,");
db[3]=new Person("3,Test-Son,,M,1,2,4,,,,");
db[4]=new Person("4,Test-Son-Wife,,F,0,0,3,,,,");
db[5]=new Person("5,Test-GrandSon,,M,3,4,0,,,,");
db[6]=new Person("6,Test-GrandDaughter,,F,3,4,0,,,,");
