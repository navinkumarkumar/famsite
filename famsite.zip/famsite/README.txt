
Step1: DEFINE Family Member Details

1) One record is defined for each family member in the excel file 'family.xlsm'in sheet 'Members'. Some sample records are already there,
   follow same way to extend family details

2) A number id is assigned to each member at COl A and this id should be in sequence and unique

3) Relations to other members are to be selected from available list. There are three basic relations. These are Father,
 	Mother and spouse

4) Name is mandatory and at least one relation should be defined for every family member

5) Export member details by pressing Export button. Name of export file must be person.js and this file to be saved in root directory

6) Relations for display in web page can be created or modified in 'Relations' sheet using basic relations. Follow same format as 
   in existing records. After defining/ updating relations, export relations via Export button.
   File name should be rel.js and to be saved in root directory

7) Individual member Image files should be with extenstion .jpg and must be put in 'Images' folder. Name of image file should  
   correspond to id of member as in excel. For example, name of file should be "2.jpg" for a member with id 2  

8) There can be up to 12 images for a member in an album. Put album files in 'Album' folder with names like: 2a1.jpg, 2a2.jpg, 2a3 ...

9) Common family image files can be put in the root folder with names fam1.jpg and famm2.jpg and so on.  

10) Test at local machine with any web browser after creating person.js and rel.js files. Index.html at root folder should be
    opened by browser

10) URL of a working site is tinyurl.com/naubasta

STEP2: PUBLISH on Internet via googledrive

1) copy entire folder 'famsite' to google drive. This should copy root folder files and sub folders Images and Album
   Give read access to public

2) use drive to web feature of google drive to publish html files on net. URL for this conversion is drw.tw
 
3) index.html in root folder is the html for launching site. Note URL created by drw.tw for index.html in root folder

4) Complex URL of google drive can be converted to simple one via 'tinyurl.com'


Support/ Feedback:    kumar_navin@yahoo.com
